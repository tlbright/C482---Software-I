/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Main.Inventory;
import Main.Part;
import Main.Product;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Andrew
 */
public class ModifyProductController implements Initializable {

    @FXML
    private TableView<Part> topTable;

    @FXML
    private TableColumn<Part, Integer> partIdTableTop;

    @FXML
    private TableColumn<Part, String> partNameTableTop;

    @FXML
    private TableColumn<Part, Integer> partInvTableTop;

    @FXML
    private TableColumn<Part, Double> partPriceTableTop;

    @FXML
    private TableView<Part> bottomTable;

    @FXML
    private TableColumn<Part, Integer> partIdTableBottom;

    @FXML
    private TableColumn<Part, String> partNameTableBottom;

    @FXML
    private TableColumn<Part, Integer> partInvTableBottom;

    @FXML
    private TableColumn<Part, Double> partPriceTableBottom;

    @FXML
    private TextField searchText;

    @FXML
    private TextField idText;

    @FXML
    private TextField nameText;

    @FXML
    private TextField invText;

    @FXML
    private TextField priceText;

    @FXML
    private TextField maxText;

    @FXML
    private TextField minText;
    
    private ObservableList<Part> bottomTablePartList = FXCollections.observableArrayList();
    
    
    Stage stage;
    Parent scene;
    
    Product product;
    Inventory inventory;
    int index;
    
    
    public ModifyProductController(Product product, Inventory inventory, int index) {
        this.product = product;
        this.inventory = inventory;
        this.index = index;
    }
    
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        topTable.setItems(inventory.getAllParts());
        
        partIdTableTop.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameTableTop.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInvTableTop.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceTableTop.setCellValueFactory(new PropertyValueFactory<>("price")); 
        
                   
        
        partIdTableBottom.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameTableBottom.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInvTableBottom.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceTableBottom.setCellValueFactory(new PropertyValueFactory<>("price")); 
               
        pullData();
        bottomTable.refresh();
        
    }    
    
        @FXML
    void cancelProductModify(ActionEvent event) throws IOException {

        boolean cancelAdd = ErrorMessage.cancelButton();
        if (cancelAdd == true) {
       
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/MainScreen.fxml"));
            MainScreenController controller = new MainScreenController(inventory);
            loader.setController(controller);
            stage.setScene(new Scene(loader.load()));
            stage.show();
        }
    }

    @FXML
    void deleteAssocPart(ActionEvent event) {
        
        Part assocPart = bottomTable.getSelectionModel().getSelectedItem();
        
        if (assocPart != null) {       
          boolean confirmDelete = ErrorMessage.deleteButton(assocPart.getName());
          if (confirmDelete == true) {
              product.deleteAssociatedPart(assocPart);
              bottomTablePartList.remove(assocPart);
              bottomTable.refresh();
          }
        }
        else {
            return;
        }
    }

    @FXML
    void addAssocPart(ActionEvent event) {
        
        Part assocPart = topTable.getSelectionModel().getSelectedItem();
        boolean repeatedPart = false;
        
        if (assocPart != null) {
            int partId = assocPart.getId();
            for (int i = 0; i < bottomTablePartList.size(); ++i) {
             if (bottomTablePartList.get(i).getId() == partId) {
                repeatedPart = true;
                ErrorMessage.productAddError(7);
             }
            }
        }
    
        if (repeatedPart == false) {
            bottomTablePartList.add(assocPart);
        }    
    
        bottomTable.setItems(bottomTablePartList);
        bottomTable.refresh();
        
    }

    @FXML
    void saveProductModify(ActionEvent event) throws IOException {

        if (nameText.getText().trim().isEmpty() || 
             invText.getText().trim().isEmpty() || 
             priceText.getText().trim().isEmpty() || 
             maxText.getText().trim().isEmpty() || 
             minText.getText().trim().isEmpty()) {
         ErrorMessage.productAddError(1);
         return;
        }
                
        if (Integer.parseInt(minText.getText().trim()) > Integer.parseInt(maxText.getText().trim())) {
             ErrorMessage.productAddError(2);
             return;
        }
         
        if (Integer.parseInt(invText.getText().trim()) < Integer.parseInt(minText.getText().trim()) || Integer.parseInt(invText.getText().trim()) > Integer.parseInt(maxText.getText().trim())) {
             ErrorMessage.productAddError(3);
             return;
        }
        
        if (Integer.parseInt(minText.getText().trim()) <= 0) {
             ErrorMessage.productAddError(4);
             return;
        }
        
        double prodCost = 0.0;
        for (int i = 0; i < bottomTablePartList.size(); ++i) {
             prodCost += bottomTablePartList.get(i).getPrice();
        }
        if (Double.parseDouble(priceText.getText().trim()) <= prodCost) {
            ErrorMessage.productAddError(5);
            return;
        }
        
        if (bottomTablePartList.isEmpty()) {
            ErrorMessage.productAddError(6);
            return;
        }
        
        
        Product prodTemp = new Product(
        Integer.parseInt(idText.getText().trim()),
        nameText.getText().trim(),
        Double.parseDouble(priceText.getText().trim()),
        Integer.parseInt(invText.getText().trim()),
        Integer.parseInt(minText.getText().trim()),
        Integer.parseInt(maxText.getText().trim()));
        
        for (int i = 0; i < bottomTablePartList.size(); ++i) {
            prodTemp.deleteAssociatedPart(bottomTablePartList.get(i));
        }    
        
                
        for (int i = 0; i < bottomTablePartList.size(); ++i) {
            prodTemp.addAssociatedPart(bottomTablePartList.get(i));
        }
        
        inventory.updateProduct(Integer.parseInt(idText.getText().trim()), prodTemp);
           
        
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/MainScreen.fxml"));
            MainScreenController controller = new MainScreenController(inventory);
            loader.setController(controller);
            stage.setScene(new Scene(loader.load()));
            stage.show();
        
        
        
    }

    @FXML
    void searchPart(ActionEvent event) {
        if (searchText.getText().isEmpty() == false) {
        topTable.setItems(inventory.lookupPart(searchText.getText().trim()));
        topTable.refresh();
     }
     else if (searchText.getText().isEmpty() == true) {
         topTable.setItems(inventory.getAllParts());
     }
        
    }
    
       private void pullData() {
        
            this.nameText.setText(product.getName());
            this.idText.setText(Integer.toString(product.getId()));
            this.invText.setText(Integer.toString(product.getStock()));
            this.priceText.setText(Double.toString(product.getPrice()));
            this.maxText.setText(Integer.toString(product.getMax()));
            this.minText.setText(Integer.toString(product.getMin()));
             
            
                   bottomTablePartList = product.getAllAssociatedParts();
          
                    bottomTable.setItems(bottomTablePartList);
            
            }
}
