package Controllers;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Main.InHouse;
import Main.Inventory;
import Main.OutSourced;
import java.io.IOException;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Andrew
 */
public class AddPartController implements Initializable {

    
    @FXML
    private RadioButton inHouseRBtn;

    @FXML
    private RadioButton outSourcedRBtn;

    @FXML
    private TextField idText;

    @FXML
    private TextField nameText;

    @FXML
    private TextField invText;

    @FXML
    private TextField priceText;

    @FXML
    private TextField maxText;

    @FXML
    private TextField minText;

    @FXML
    private TextField machText;
        
    @FXML
    private Label machLabel;
 
    Stage stage;
    Parent scene;
    Inventory inventory;
   
        
    public AddPartController(Inventory inventory) {
       this.inventory = inventory;
   }
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        partId();
    }    
    


    @FXML
    void inHouseRadio(ActionEvent event) {
     machLabel.setText("Machine ID");
     machText.setPromptText("Machine ID");
    }

    @FXML
    void outSourceRadio(ActionEvent event) {
     machLabel.setText("Company Name");
     machText.setPromptText("Company Name");
    }

    @FXML
    void savePartAdd(ActionEvent event) throws IOException {


        if (nameText.getText().trim().isEmpty() || 
             invText.getText().trim().isEmpty() || 
             priceText.getText().trim().isEmpty() || 
             maxText.getText().trim().isEmpty() || 
             minText.getText().trim().isEmpty() || 
             machLabel.getText().trim().isEmpty()) {
         ErrorMessage.partAddError(1);
         return;
        }
         
        if (Integer.parseInt(minText.getText().trim()) > Integer.parseInt(maxText.getText().trim())) {
             ErrorMessage.partAddError(2);
             return;
        }
         
        if (Integer.parseInt(invText.getText().trim()) < Integer.parseInt(minText.getText().trim()) || Integer.parseInt(invText.getText().trim()) > Integer.parseInt(maxText.getText().trim())) {
             ErrorMessage.partAddError(3);
             return;
        }
        
        if (Integer.parseInt(minText.getText().trim()) <= 0) {
             ErrorMessage.partAddError(4);
        } 
        
        if (inHouseRBtn.isSelected()) {
          partAddInHouse();
        }
        else if (outSourcedRBtn.isSelected()) {
          partAddOutSourced();
        }
      
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/MainScreen.fxml"));
            MainScreenController controller = new MainScreenController(inventory);
            loader.setController(controller);
            stage.setScene(new Scene(loader.load()));
      
    }
    
    @FXML
    void cancelPartAdd(ActionEvent event) throws IOException {
        
        boolean cancelAdd = ErrorMessage.cancelButton();
        if (cancelAdd == true) {
       
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/MainScreen.fxml"));
            MainScreenController controller = new MainScreenController(inventory);
            loader.setController(controller);
            stage.setScene(new Scene(loader.load()));
        }
    }
    
    private void partAddInHouse() {
        
        int id = Integer.parseInt(idText.getText().trim());
        String name = nameText.getText().trim();
        int stock = Integer.parseInt(invText.getText().trim());
        double price = Double.parseDouble(priceText.getText().trim());
        int max = Integer.parseInt(maxText.getText().trim());
        int min = Integer.parseInt(minText.getText().trim());
        int machineId = Integer.parseInt(machText.getText().trim());
        
        inventory.addPart(new InHouse(id, name, price, stock, min, max, machineId));
        
    }
    
    private void partAddOutSourced() {
        
        int id = Integer.parseInt(idText.getText().trim());
        String name = nameText.getText().trim();
        int stock = Integer.parseInt(invText.getText().trim());
        double price = Double.parseDouble(priceText.getText().trim());
        int max = Integer.parseInt(maxText.getText().trim());
        int min = Integer.parseInt(minText.getText().trim());
        String companyName = machLabel.getText().trim();
        
        inventory.addPart(new OutSourced(id, name, price, stock, min, max, companyName));
        
    }
    
    private void partId() {
        
        Random randomId = new Random();
        Integer partId = randomId.nextInt(999);
        idText.setText(partId.toString());
         
    }
    
    
}
