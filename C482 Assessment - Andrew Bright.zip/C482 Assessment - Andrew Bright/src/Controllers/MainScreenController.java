/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Main.Inventory;
import Main.Part;
import Main.Product;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Andrew
 */
public class MainScreenController implements Initializable {
    
    @FXML
    private TableView<Product> productTable;

    @FXML
    private TableColumn<Product, Integer> productIDTable;

    @FXML
    private TableColumn<Product, String> productNameTable;

    @FXML
    private TableColumn<Product, Integer> productInvTable;

    @FXML
    private TableColumn<Product, Double> productPriceTable;

    @FXML
    private TableView<Part> partTable;

    @FXML
    private TableColumn<Part, Integer> partIDTable;

    @FXML
    private TableColumn<Part, String> partNameTable;

    @FXML
    private TableColumn<Part, Integer> partInvTable;

    @FXML
    private TableColumn<Part, Double> partPriceTable;
        
    @FXML
    private TextField partSearchText;
    
    @FXML
    private TextField productSearchText;
        
    Stage stage;
    Parent scene;
    Inventory inventory;
    
    /**
     * Initializes the controller class.
     * @param inventory
     */  
    
    public MainScreenController(Inventory inventory) {
       this.inventory = inventory;
   }
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        productTable.setItems(inventory.getAllProducts());
        
        productIDTable.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameTable.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInvTable.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productPriceTable.setCellValueFactory(new PropertyValueFactory<>("price"));
        
        
        
        partTable.setItems(inventory.getAllParts());
        
        partIDTable.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameTable.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInvTable.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceTable.setCellValueFactory(new PropertyValueFactory<>("price")); 
        
        
        
    } 
    
    @FXML
    void addPartScreen(ActionEvent event) throws IOException {

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/AddPart.fxml"));
            AddPartController controller = new AddPartController(inventory);
            loader.setController(controller);
            stage.setScene(new Scene(loader.load()));
            stage.show();
        
        
    }

    @FXML
    void addProductScreen(ActionEvent event) throws IOException {

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/AddProduct.fxml"));
            AddProductController controller = new AddProductController(inventory);
            loader.setController(controller);
            stage.setScene(new Scene(loader.load()));
            stage.show();
        
        
    }

    @FXML
    void deletePart(ActionEvent event) {

        Part partDelete = partTable.getSelectionModel().getSelectedItem();
        
        boolean confirmDelete = ErrorMessage.deleteButton(partDelete.getName());
        if (confirmDelete == true) {
            inventory.deletePart(partDelete);
            partTable.refresh();
        }
        
    }
    
    @FXML
    void deleteProduct(ActionEvent event) {

        Product productDelete = productTable.getSelectionModel().getSelectedItem();
        
        boolean confirmDelete = ErrorMessage.deleteButton(productDelete.getName());
        if (confirmDelete == true) {
            inventory.deleteProduct(productDelete);
            productTable.refresh();
        }
        
    }

    @FXML
    void modifyPartScreen(ActionEvent event) throws IOException {

        Part partSelect = partTable.getSelectionModel().getSelectedItem();
        
        if (partTable.getSelectionModel().getSelectedItem() == null) {
            ErrorMessage.infoMessage();
            return;
        }
        if (inventory.getAllParts().isEmpty() == false) {
            
            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/ModifyPart.fxml"));
            ModifyPartController controller = new ModifyPartController(partSelect, inventory);
            loader.setController(controller);
            stage.setScene(new Scene(loader.load()));
            stage.show();
        }
    }
        
    @FXML
    void modifyProductScreen(ActionEvent event) throws IOException {

        Product productSelect = productTable.getSelectionModel().getSelectedItem();
        int index = inventory.getAllProducts().indexOf(productSelect);
                
        if (productTable.getSelectionModel().getSelectedItem() == null) {
            ErrorMessage.infoMessage();
            return;
        }
        if (inventory.getAllProducts().isEmpty() == false) {
            
            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/ModifyProduct.fxml"));
            ModifyProductController controller = new ModifyProductController(productSelect, inventory, index);
            loader.setController(controller);
            stage.setScene(new Scene(loader.load()));
            stage.show();
        }
        
    }

    @FXML
    void searchPart(ActionEvent event) {

     if (partSearchText.getText().trim().isEmpty() == false) {
        partTable.setItems(inventory.lookupPart(partSearchText.getText().trim()));
        partTable.refresh();
     }
     else if (partSearchText.getText().isEmpty() == true) {
         partTable.setItems(inventory.getAllParts());
     }
        

                
    }

    @FXML
    void searchProduct(ActionEvent event) {
     
     if (productSearchText.getText().trim().isEmpty() == false) {
        productTable.setItems(inventory.lookupProduct(productSearchText.getText().trim()));
        productTable.refresh();
     }
     else if (productSearchText.getText().isEmpty() == true) {
         productTable.setItems(inventory.getAllProducts());
     }
        
    }
    
    
    
    
    @FXML
    void exitProgram(ActionEvent event) {

       System.exit(0);
    } 
    
    
 
    
}
