/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;

/**
 *
 * @author Andrew
 */
public class ErrorMessage {
    
   public static void partAddError(int errorNum) {
      
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle("ERROR");
    alert.setHeaderText("Unable to add part");
    
    switch(errorNum) {
    
    case 1: {
        alert.setContentText("Please fill all available fields");
        break;
    }
    
    case 2: {
        alert.setContentText("Minimum must be below maximum");
        break;
    }
    
    case 3: {
        alert.setContentText("Inventory level must be between minimum and maximum");
        break;
    }
    case 4: {
        alert.setContentText("Minimum must be greater than zero");
        break;
    }
    
    default: {
        alert.setContentText("Error: Unknown Error");
        break;
    }
    }  
   alert.show();
         
   }
   
   
    public static void productAddError(int errorNum) {
      
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle("ERROR");
    alert.setHeaderText("Unable to add product");
    
    switch(errorNum) {
    
    case 1: {
        alert.setContentText("Please fill all available fields");
        break;
    }
    
    case 2: {
        alert.setContentText("Minimum must be below maximum");
        break;
    }
    
    case 3: {
        alert.setContentText("Inventory level must be between minimum and maximum");
        break;
    }
    case 4: {
        alert.setContentText("Minimum must be greater than zero");
        break;
    }
    case 5: {
        alert.setContentText("Product cost must be more than corresponding part(s) cost");
        break;
    }
    case 6: {
        alert.setContentText("Product must have at least one associated part");
        break;
    }
    case 7: {
        alert.setContentText("Part is already associated with selected product");
        break;
    }
    
    default: {
        alert.setContentText("Error: Unknown Error");
        break;
     }
    }  
   alert.show();
         
   }
    
    
    public static boolean cancelButton() {
    
    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
    alert.setTitle(null);
    alert.setHeaderText("Are you sure you want to cancel?");
    alert.setContentText("Click OK to continue");
    Optional<ButtonType> cancel = alert.showAndWait();
    return cancel.get() == ButtonType.OK;
    }
    
    public static boolean deleteButton(String name) {
    
    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
    alert.setTitle(null);
    alert.setHeaderText("Are you sure you want to delete: " + name + "?");
    alert.setContentText("Click OK to continue");
    Optional<ButtonType> cancel = alert.showAndWait();
    return cancel.get() == ButtonType.OK;
    }
    
    public static void infoMessage() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(null);
        alert.setHeaderText("Please make a selection from the above table to modify");
        alert.setContentText("Click OK to continue");
        alert.showAndWait();
    }
   
  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
