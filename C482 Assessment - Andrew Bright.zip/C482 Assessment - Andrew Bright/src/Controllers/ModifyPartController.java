/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Main.InHouse;
import Main.Inventory;
import Main.OutSourced;
import Main.Part;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Andrew
 */
public class ModifyPartController implements Initializable {

     @FXML
    private RadioButton outsourcedRBtn;

    @FXML
    private RadioButton inHouseRBtn;

    @FXML
    private TextField idText;

    @FXML
    private TextField nameText;

    @FXML
    private TextField invText;

    @FXML
    private TextField priceText;

    @FXML
    private TextField maxText;

    @FXML
    private TextField minText;
    
    @FXML
    private Label machLabel;

    @FXML
    private TextField machText;
    
    Stage stage;
    Parent scene;
    Part part;
    Inventory inventory;
    
   public ModifyPartController(Part part, Inventory inventory) {
       this.part = part;
       this.inventory = inventory;
   }
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
      pullData();
    }    
    
    
    @FXML
    void cancelProductAdd(ActionEvent event) throws IOException {

        boolean cancelAdd = ErrorMessage.cancelButton();
        if (cancelAdd == true) {
       
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/MainScreen.fxml"));
            MainScreenController controller = new MainScreenController(inventory);
            loader.setController(controller);
            stage.setScene(new Scene(loader.load()));
            stage.show();
        }
    }

    @FXML
    void inHouseRadio(ActionEvent event) {
     machLabel.setText("Machine ID");
     machText.setPromptText("Machine ID");
    }

    @FXML
    void outsourcedRadio(ActionEvent event) {
     machLabel.setText("Company Name");
     machText.setPromptText("Company Name");
    }

    @FXML
    void saveProductAdd(ActionEvent event) throws IOException {

        if (nameText.getText().trim().isEmpty() || 
             invText.getText().trim().isEmpty() || 
             priceText.getText().trim().isEmpty() || 
             maxText.getText().trim().isEmpty() || 
             minText.getText().trim().isEmpty() || 
             machLabel.getText().trim().isEmpty()) {
         ErrorMessage.partAddError(1);
         return;
        }
         
        if (Integer.parseInt(minText.getText().trim()) > Integer.parseInt(maxText.getText().trim())) {
             ErrorMessage.partAddError(2);
             return;
        }
         
        if (Integer.parseInt(invText.getText().trim()) < Integer.parseInt(minText.getText().trim()) || Integer.parseInt(invText.getText().trim()) > Integer.parseInt(maxText.getText().trim())) {
             ErrorMessage.partAddError(3);
             return;
        }
        
        if (Integer.parseInt(minText.getText().trim()) <= 0) {
             ErrorMessage.partAddError(4);
        } 
        
        else if (inHouseRBtn.isSelected() && part instanceof InHouse) {
          partUpdateInHouse();
        }
        
        else if (inHouseRBtn.isSelected() && part instanceof OutSourced) {
          partUpdateInHouse();
        }

        else if (outsourcedRBtn.isSelected() && part instanceof OutSourced) {
          partUpdateOutSourced();
        }
        
        else if (outsourcedRBtn.isSelected() && part instanceof InHouse) {
          partUpdateOutSourced();
        }
      
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/MainScreen.fxml"));
            MainScreenController controller = new MainScreenController(inventory);
            loader.setController(controller);
            stage.setScene(new Scene(loader.load()));
            stage.show();
      
    }
    
    private void partUpdateInHouse() {
       
        inventory.updatePart(Integer.parseInt(idText.getText().trim()), new InHouse(
        Integer.parseInt(idText.getText().trim()),
        nameText.getText().trim(),
        Double.parseDouble(priceText.getText().trim()),
        Integer.parseInt(invText.getText().trim()),
        Integer.parseInt(maxText.getText().trim()),
        Integer.parseInt(minText.getText().trim()),
        Integer.parseInt(machText.getText().trim())));
        
    }
    
    private void partUpdateOutSourced() {
       
        inventory.updatePart(Integer.parseInt(idText.getText().trim()), new OutSourced(
        Integer.parseInt(idText.getText().trim()),
        nameText.getText().trim(),
        Double.parseDouble(priceText.getText().trim()),
        Integer.parseInt(invText.getText().trim()),
        Integer.parseInt(maxText.getText().trim()),
        Integer.parseInt(minText.getText().trim()),
        machText.getText().trim()));
        
    }
    
   private void pullData() {
        
        if (part instanceof InHouse) {
            
            inHouseRBtn.setSelected(true);
            InHouse partInHouse = (InHouse) part;
            machLabel.setText("Machine ID");
            machText.setPromptText("Machine ID");
            this.nameText.setText(partInHouse.getName());
            this.idText.setText(Integer.toString(partInHouse.getId()));
            this.invText.setText(Integer.toString(partInHouse.getStock()));
            this.priceText.setText(Double.toString(partInHouse.getPrice()));
            this.maxText.setText(Integer.toString(partInHouse.getMax()));
            this.minText.setText(Integer.toString(partInHouse.getMin()));
            this.machText.setText(Integer.toString(partInHouse.getMachineId()));
        }
        
        
        if (part instanceof OutSourced) {
            
            outsourcedRBtn.setSelected(true);
            OutSourced partOutSourced = (OutSourced) part;
            machLabel.setText("Company Name");
            machText.setPromptText("Company Name");
            this.nameText.setText(partOutSourced.getName());
            this.idText.setText(Integer.toString(partOutSourced.getId()));
            this.invText.setText(Integer.toString(partOutSourced.getStock()));
            this.priceText.setText(Double.toString(partOutSourced.getPrice()));
            this.maxText.setText(Integer.toString(partOutSourced.getMax()));
            this.minText.setText(Integer.toString(partOutSourced.getMin()));
            this.machText.setText(partOutSourced.getCompanyName());
        }    
        
    } 
        
        
        
}
