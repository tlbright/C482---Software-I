/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;


import Controllers.MainScreenController;
import java.io.IOException;
import Main.Inventory;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;


/**
 *
 * @author Andrew
 */
public class InventoryProgram extends Application {
    

    Stage stage;
    Parent scene; 
    Inventory inventory;
    
   @Override
   public void start(Stage stage) throws Exception{
       Inventory inventory = new Inventory();
       initializeData(inventory);
       
       FXMLLoader loader = new FXMLLoader(getClass().getResource("/GUI/MainScreen.fxml"));
       MainScreenController controller = new MainScreenController(inventory);
       loader.setController(controller);
       Scene scene = new Scene(loader.load());
       
       stage.setScene(scene);
       stage.setResizable(false);
       stage.show();
   }


    public static void main(String[] args) {
                       
        launch(args);
    }
    
    public void initializeData(Inventory inventory) {
                
        Part part1 = new InHouse(1, "Part 1", 4.99, 4, 1, 5, 30);
        Part part2 = new InHouse(2, "Part 2", 8.99, 6, 1, 10, 50);
        Part part3 = new InHouse(3, "Part 3", 10.49, 20, 1, 35, 60);
        Part part4 = new OutSourced(4, "Part 4", 15.99, 30, 1, 40, "Nodda-Real LLC");
        Part part5 = new OutSourced(5, "Part 5", 25.49, 50, 1, 60, "Staged Inc.");
        Part part6 = new OutSourced(6, "Part 6", 55.99, 50, 1, 75, "Improvised Co.");
        
        inventory.addPart(part1);
        inventory.addPart(part2);
        inventory.addPart(part3);
        inventory.addPart(part4);
        inventory.addPart(part5);
        inventory.addPart(part6);
        
        Product product1 = new Product(1, "Product 1", 18.99, 3, 1, 5); 
        Product product2 = new Product(2, "Product 2", 9.99, 4, 1, 10);
        Product product3 = new Product(3, "Product 3", 35.99, 5, 1, 15);
        Product product4 = new Product(4, "Product 4", 38.99, 6, 1, 20);
        Product product5 = new Product(5, "Product 5", 49.99, 7, 1, 25);
        Product product6 = new Product(6, "Product 6", 99.99, 8, 1, 35);

        
        
        inventory.addProduct(product1);
        inventory.addProduct(product2);
        inventory.addProduct(product3);
        inventory.addProduct(product4);
        inventory.addProduct(product5);
        inventory.addProduct(product6);
        
        product1.addAssociatedPart(part1);
        product1.addAssociatedPart(part3);
        
        product2.addAssociatedPart(part2);
        
        product3.addAssociatedPart(part3);
        product3.addAssociatedPart(part4);
        
        product4.addAssociatedPart(part4);
        
        product5.addAssociatedPart(part5);
        product5.addAssociatedPart(part4);
        
        product6.addAssociatedPart(part6);
        product6.addAssociatedPart(part5);
        
    }


    /**
     * @param args the command line arguments
     */

    
}
