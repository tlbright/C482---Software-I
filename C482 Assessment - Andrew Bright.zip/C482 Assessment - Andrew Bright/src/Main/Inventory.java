/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Controllers.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Andrew
 */
public class Inventory {
    
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();  
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    

public void addPart(Part partNew) {
    if (partNew != null) {
        allParts.add(partNew);
    }
}
    
    public void addProduct(Product productNew) {
    if (productNew != null) {
        this.allProducts.add(productNew);
    }
}
        
public Part lookupPart(int partSearch) {
    if (allParts.isEmpty() == false) {
        for (int i = 0; i < allParts.size(); ++i) {
            if (allParts.get(i).getId() == partSearch) {
                return allParts.get(i);
            }
        }
    }
    return null;
}

public Product lookupProduct(int productSearch) {
        if (allProducts.isEmpty() == false) {
        for (int i = 0; i < allProducts.size(); ++i) {
            if (allProducts.get(i).getId() == productSearch) {
                return allProducts.get(i);
            }
        }
    }
    return null;
}
        
public ObservableList<Part> lookupPart(String partNameSearch) {
    
    if (allParts.isEmpty() == false) {
        ObservableList partSearch = FXCollections.observableArrayList();
        for (Part partForSearch : getAllParts()) {
            if (partForSearch.getName().contains(partNameSearch)) {
                partSearch.add(partForSearch);
            }
        }
        return partSearch;
    } 
    
    return null;
}
        
public  ObservableList<Product> lookupProduct(String productNameSearch) {
    
    if (allProducts.isEmpty() == false) {
        ObservableList productSearch = FXCollections.observableArrayList();
        for (Product productForSearch : getAllProducts()) {
            if (productForSearch.getName().contains(productNameSearch)) {
                productSearch.add(productForSearch);
            }
        }
        return productSearch;
    } 
    
    
    return null;
}
        
public void updatePart(int index, Part partUpdate) {
    for (index = 0; index < allParts.size(); ++index) {
        if (allParts.get(index).getId() == partUpdate.getId()) {
            allParts.set(index, partUpdate);
            break;
        }
    }
}
        
public void updateProduct(int index, Product productUpdate) {
        for (index = 0; index < allProducts.size(); ++index) {
        if (allProducts.get(index).getId() == productUpdate.getId()) {
            allProducts.set(index, productUpdate);
            break;
        }
    }
}
        
public boolean deletePart(Part partSelected) {
            for (int i = 0; i < allParts.size(); ++i) {
        if (allParts.get(i).getId() == partSelected.getId()) {
            allParts.remove(i);
            return true;
        }
    }
        return false;
}
        
public boolean deleteProduct(Product productSelected) {
        for (int i = 0; i < allProducts.size(); ++i) {
        if (allProducts.get(i).getId() == productSelected.getId()) {
            allProducts.remove(i);
            return true;
        }
    }
        return false;
}
        
public ObservableList<Part> getAllParts() {
    return allParts;
}
        
public ObservableList<Product> getAllProducts() {
    return allProducts;
}

       
}
