/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author Andrew
 */
public class OutSourced extends Part {
    
    private String companyName;
    
    public OutSourced (int id, String name, double price, int stock, int min, int max, String companyName) {
        
        setId(id);
        setName(name);
        setPrice(price);
        setStock(stock);
        setMax(max);
        setMin(min);
        setCompanyName(companyName);
    
    }
    
    public void setCompanyName (String companyName) {
        this.companyName = companyName;
    }
    public String getCompanyName () {
        return companyName;
    }
}
